# ECE 120 (fa24) repo for NetID: jleit3

GitHub username at initialization time: jleithal

For next steps, please refer to the instructions provided by your course.
