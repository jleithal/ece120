#include <stdio.h>
int main() {
    int val1 = 12;
    int val2 = 3;
    int res;

    res = val1 % val2;

    printf("%d\n", res);

    return 0;
}

